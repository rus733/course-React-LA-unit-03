function Header() {
  return (
    <nav>
      <h1>Header</h1>
      <li>
        <a href="/">Главная</a>
      </li>
      <li>
        <a href="/about">О сайте</a>
      </li>
      <li>
        <a href="/cat">Категории</a>
      </li>
    </nav>
  );
}

export default Header;
