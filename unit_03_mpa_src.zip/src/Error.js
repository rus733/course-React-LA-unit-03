function Error() {
  return (
    <>
      <h1>Error 404 Страница по запрашиваемому адресу не существует</h1>
    </>
  );
}
export default Error;
